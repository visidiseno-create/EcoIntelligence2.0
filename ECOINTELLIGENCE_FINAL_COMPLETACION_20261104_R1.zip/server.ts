import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dbManager } from './src/server/database';
import {
  calculateComplianceRate,
  aggregateWasteMetrics,
  aggregateWaterMetrics,
  evaluateAirCompliance,
  calculateEnergyIntensity,
  answerEnvironmentalQuery
} from './src/utils/metrics';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true }));

  // Middleware: Organization context and tenant isolation
  // In demo laboratory mode, we extract active organization from header or fallback to default
  const getContextOrgId = (req: Request): string => {
    return (req.headers['x-organization-id'] as string) || 'org-1';
  };

  const getActorInfo = (req: Request) => {
    const actorEmail = (req.headers['x-user-email'] as string) || 'admin@ecoinntelligence.com';
    const db = dbManager.get();
    const user = db.users.find(u => u.email === actorEmail) || db.users[0];
    return {
      name: user?.name || 'Administrador Ambiental',
      role: user?.role || 'admin',
      email: actorEmail
    };
  };

  // 1. Auth routes
  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { email } = req.body;
    const db = dbManager.get();
    const targetEmail = email ? email.trim().toLowerCase() : 'admin@ecoinntelligence.com';
    const user = db.users.find(u => u.email.toLowerCase() === targetEmail);

    if (!user) {
      // Allow fallback to first user or create guest operator
      return res.status(401).json({ error: 'Credenciales inválidas en el laboratorio.' });
    }

    const org = db.organizations.find(o => o.id === user.organizationId) || db.organizations[0];
    dbManager.addAuditLog(user.organizationId, user.name, user.role, 'INICIO_SESION', 'Autenticación', `Acceso exitoso al sistema como rol: ${user.role}`);

    res.json({
      success: true,
      user,
      organization: org,
      availableOrganizations: db.organizations
    });
  });

  app.get('/api/auth/me', (req: Request, res: Response) => {
    const actor = getActorInfo(req);
    const db = dbManager.get();
    const user = db.users.find(u => u.email === actor.email) || db.users[0];
    const orgId = getContextOrgId(req);
    const org = db.organizations.find(o => o.id === orgId) || db.organizations[0];

    res.json({
      user,
      organization: org,
      availableOrganizations: db.organizations
    });
  });

  app.get('/api/auth/users', (req: Request, res: Response) => {
    const db = dbManager.get();
    res.json(db.users);
  });

  // 2. Organizations & Facilities
  app.get('/api/organizations', (_req: Request, res: Response) => {
    const db = dbManager.get();
    res.json(db.organizations);
  });

  app.post('/api/organizations', (req: Request, res: Response) => {
    const { name, taxId, sector, country } = req.body;
    if (!name || !taxId) {
      return res.status(400).json({ error: 'Nombre y RUC/Identificación fiscal son requeridos.' });
    }
    const db = dbManager.get();
    const newOrg = {
      id: `org-${Date.now()}`,
      name,
      taxId,
      sector: sector || 'General',
      country: country || 'Perú',
      plan: 'pro' as const,
      createdAt: new Date().toISOString().split('T')[0]
    };
    db.organizations.push(newOrg);
    dbManager.save();
    res.status(201).json(newOrg);
  });

  app.get('/api/facilities', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const list = db.facilities.filter(f => f.organizationId === orgId);
    res.json(list);
  });

  app.post('/api/facilities', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const { name, code, address, activity, environmentalPermitCode, coordinates } = req.body;

    if (!name || !code) {
      return res.status(400).json({ error: 'Nombre e identificador de instalación son obligatorios.' });
    }

    const db = dbManager.get();
    const newFac = {
      id: `fac-${Date.now()}`,
      organizationId: orgId,
      name,
      code,
      address: address || 'Sin dirección especificada',
      coordinates: coordinates || { lat: -12.0464, lng: -77.0428 },
      activity: activity || 'Actividad industrial',
      environmentalPermitCode: environmentalPermitCode || 'S/N',
      status: 'activa' as const
    };

    db.facilities.push(newFac);
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'CREACION_INSTALACION', 'Instalaciones', `Nueva instalación registrada: ${name} (${code})`);
    dbManager.save();
    res.status(201).json(newFac);
  });

  // 3. Environmental Obligations
  app.get('/api/obligations', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const { facilityId, status, search } = req.query;
    const db = dbManager.get();
    let list = db.obligations.filter(o => o.organizationId === orgId);

    if (facilityId) {
      list = list.filter(o => o.facilityId === facilityId);
    }
    if (status) {
      list = list.filter(o => o.status === status);
    }
    if (search && typeof search === 'string') {
      const term = search.toLowerCase();
      list = list.filter(o => 
        o.title.toLowerCase().includes(term) || 
        o.normativeSource.toLowerCase().includes(term) ||
        o.responsible.toLowerCase().includes(term)
      );
    }

    res.json(list);
  });

  app.post('/api/obligations', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const { title, facilityId, normativeSource, jurisdiction, dueDate, frequency, responsible, description } = req.body;

    if (!title || !normativeSource || !dueDate) {
      return res.status(400).json({ error: 'Título, fuente normativa y fecha de vencimiento son requeridos.' });
    }

    const db = dbManager.get();
    const newObligation = {
      id: `ob-${Date.now()}`,
      organizationId: orgId,
      facilityId: facilityId || db.facilities.find(f => f.organizationId === orgId)?.id || '',
      title,
      normativeSource,
      jurisdiction: jurisdiction || 'Nacional',
      dueDate,
      frequency: frequency || 'anual',
      responsible: responsible || actor.name,
      status: 'pendiente' as const,
      evidenceCount: 0,
      description: description || ''
    };

    db.obligations.push(newObligation);
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'CREACION_OBLIGACION', 'Cumplimiento', `Registrada obligación ambiental: "${title}"`);
    dbManager.save();
    res.status(201).json(newObligation);
  });

  app.put('/api/obligations/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const db = dbManager.get();
    const idx = db.obligations.findIndex(o => o.id === id && o.organizationId === orgId);

    if (idx === -1) {
      return res.status(404).json({ error: 'Obligación no encontrada.' });
    }

    const updated = { ...db.obligations[idx], ...req.body };
    db.obligations[idx] = updated;
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'ACTUALIZACION_OBLIGACION', 'Cumplimiento', `Actualizada obligación "${updated.title}" a estado: ${updated.status}`);
    dbManager.save();
    res.json(updated);
  });

  app.delete('/api/obligations/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const db = dbManager.get();
    const idx = db.obligations.findIndex(o => o.id === id && o.organizationId === orgId);

    if (idx === -1) {
      return res.status(404).json({ error: 'Obligación no encontrada.' });
    }

    const removed = db.obligations.splice(idx, 1)[0];
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'ELIMINACION_OBLIGACION', 'Cumplimiento', `Eliminada obligación: "${removed.title}"`);
    dbManager.save();
    res.json({ success: true });
  });

  // 4. Waste Management
  app.get('/api/waste', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const list = db.wasteRecords.filter(w => w.organizationId === orgId);
    res.json(list);
  });

  app.post('/api/waste', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const { facilityId, date, wasteName, category, quantityKg, originProcess, carrier, destination, treatmentType, manifestNumber } = req.body;

    if (!wasteName || !quantityKg) {
      return res.status(400).json({ error: 'Nombre de residuo y cantidad en kg son requeridos.' });
    }

    const db = dbManager.get();
    const newRecord = {
      id: `w-${Date.now()}`,
      organizationId: orgId,
      facilityId: facilityId || db.facilities.find(f => f.organizationId === orgId)?.id || '',
      date: date || new Date().toISOString().split('T')[0],
      wasteName,
      category: category || 'no_peligroso',
      quantityKg: Number(quantityKg),
      originProcess: originProcess || 'Operación general',
      carrier: carrier || 'Operador de Residuos Autorizado',
      destination: destination || 'Planta de Tratamiento / Relleno',
      treatmentType: treatmentType || 'disposicion_final',
      manifestNumber: manifestNumber || `MAN-${Date.now().toString().slice(-4)}`
    };

    db.wasteRecords.push(newRecord);
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'REGISTRO_RESIDUOS', 'Residuos', `Registrado residuo ${wasteName} (${quantityKg} kg)`);
    dbManager.save();
    res.status(201).json(newRecord);
  });

  app.delete('/api/waste/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const idx = db.wasteRecords.findIndex(w => w.id === id && w.organizationId === orgId);
    if (idx === -1) return res.status(404).json({ error: 'Registro no encontrado.' });
    db.wasteRecords.splice(idx, 1);
    dbManager.save();
    res.json({ success: true });
  });

  // 5. Water Management
  app.get('/api/water', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const list = db.waterRecords.filter(w => w.organizationId === orgId);
    res.json(list);
  });

  app.post('/api/water', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const { facilityId, date, source, volumeConsumedM3, volumeDischargedM3, dischargePermitCompliant, bod5MgL, codMgL, ph } = req.body;

    if (volumeConsumedM3 === undefined) {
      return res.status(400).json({ error: 'Volumen consumido en m3 es requerido.' });
    }

    const db = dbManager.get();
    const newRecord = {
      id: `wt-${Date.now()}`,
      organizationId: orgId,
      facilityId: facilityId || db.facilities.find(f => f.organizationId === orgId)?.id || '',
      date: date || new Date().toISOString().split('T')[0],
      source: source || 'red_publica',
      volumeConsumedM3: Number(volumeConsumedM3),
      volumeDischargedM3: Number(volumeDischargedM3 || 0),
      dischargePermitCompliant: dischargePermitCompliant ?? true,
      bod5MgL: bod5MgL ? Number(bod5MgL) : undefined,
      codMgL: codMgL ? Number(codMgL) : undefined,
      ph: ph ? Number(ph) : undefined
    };

    db.waterRecords.push(newRecord);
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'REGISTRO_AGUA', 'Recursos Hídricos', `Registrado consumo de agua: ${volumeConsumedM3} m³`);
    dbManager.save();
    res.status(201).json(newRecord);
  });

  app.delete('/api/water/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const idx = db.waterRecords.findIndex(w => w.id === id && w.organizationId === orgId);
    if (idx === -1) return res.status(404).json({ error: 'Registro no encontrado.' });
    db.waterRecords.splice(idx, 1);
    dbManager.save();
    res.json({ success: true });
  });

  // 6. Air & Emissions
  app.get('/api/air', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const list = db.airRecords.filter(a => a.organizationId === orgId);
    res.json(list);
  });

  app.post('/api/air', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const { facilityId, date, emissionSource, parameter, measuredValue, limitValue, unit } = req.body;

    if (!emissionSource || measuredValue === undefined || !limitValue) {
      return res.status(400).json({ error: 'Fuente de emisión, valor medido y límite son requeridos.' });
    }

    const db = dbManager.get();
    const newRecord = {
      id: `air-${Date.now()}`,
      organizationId: orgId,
      facilityId: facilityId || db.facilities.find(f => f.organizationId === orgId)?.id || '',
      date: date || new Date().toISOString().split('T')[0],
      emissionSource,
      parameter: parameter || 'PM10',
      measuredValue: Number(measuredValue),
      limitValue: Number(limitValue),
      unit: unit || 'mg/Nm3'
    };

    db.airRecords.push(newRecord);
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'REGISTRO_AIRE', 'Emisiones y Aire', `Monitoreo de ${parameter} en ${emissionSource}: ${measuredValue} ${unit}`);
    dbManager.save();
    res.status(201).json(newRecord);
  });

  app.delete('/api/air/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const idx = db.airRecords.findIndex(a => a.id === id && a.organizationId === orgId);
    if (idx === -1) return res.status(404).json({ error: 'Registro no encontrado.' });
    db.airRecords.splice(idx, 1);
    dbManager.save();
    res.json({ success: true });
  });

  // 7. Energy
  app.get('/api/energy', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const list = db.energyRecords.filter(e => e.organizationId === orgId);
    res.json(list);
  });

  app.post('/api/energy', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const { facilityId, date, sourceType, consumptionKWh, costUsd } = req.body;

    if (consumptionKWh === undefined) {
      return res.status(400).json({ error: 'Consumo en kWh es requerido.' });
    }

    const db = dbManager.get();
    const newRecord = {
      id: `en-${Date.now()}`,
      organizationId: orgId,
      facilityId: facilityId || db.facilities.find(f => f.organizationId === orgId)?.id || '',
      date: date || new Date().toISOString().split('T')[0],
      sourceType: sourceType || 'red_electrica',
      consumptionKWh: Number(consumptionKWh),
      costUsd: costUsd ? Number(costUsd) : undefined
    };

    db.energyRecords.push(newRecord);
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'REGISTRO_ENERGIA', 'Gestión Energética', `Consumo energético registrado: ${consumptionKWh} kWh (${sourceType})`);
    dbManager.save();
    res.status(201).json(newRecord);
  });

  app.delete('/api/energy/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const idx = db.energyRecords.findIndex(e => e.id === id && e.organizationId === orgId);
    if (idx === -1) return res.status(404).json({ error: 'Registro no encontrado.' });
    db.energyRecords.splice(idx, 1);
    dbManager.save();
    res.json({ success: true });
  });

  // 8. Inspections & CAPA
  app.get('/api/inspections/templates', (_req: Request, res: Response) => {
    const db = dbManager.get();
    res.json(db.inspectionTemplates);
  });

  app.get('/api/inspections', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const list = db.inspections.filter(i => i.organizationId === orgId);
    res.json(list);
  });

  app.post('/api/inspections', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const { facilityId, templateId, title, date, inspector, score, summary, findings } = req.body;

    if (!title) {
      return res.status(400).json({ error: 'Título de la inspección es requerido.' });
    }

    const db = dbManager.get();
    const newInspection = {
      id: `insp-${Date.now()}`,
      organizationId: orgId,
      facilityId: facilityId || db.facilities.find(f => f.organizationId === orgId)?.id || '',
      templateId: templateId || 'tmpl-1',
      title,
      date: date || new Date().toISOString().split('T')[0],
      inspector: inspector || actor.name,
      status: 'completada' as const,
      score: score !== undefined ? Number(score) : 85,
      summary: summary || 'Inspección completada conforme a lista de verificación.',
      findings: Array.isArray(findings) ? findings : []
    };

    db.inspections.push(newInspection);

    // If findings require action, auto-create corrective actions
    if (Array.isArray(findings)) {
      for (const f of findings) {
        if (f.actionRequired) {
          db.correctiveActions.push({
            id: `capa-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            organizationId: orgId,
            facilityId: newInspection.facilityId,
            inspectionId: newInspection.id,
            title: `Acción derivada de hallazgo: ${f.description.slice(0, 50)}...`,
            findingDescription: f.description,
            rootCause: 'Pendiente análisis causal de 5 Porqués por equipo de planta',
            proposedAction: 'Implementar medida correctiva y verificar evidencia',
            responsible: actor.name,
            deadline: new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0],
            status: 'abierta'
          });
        }
      }
    }

    dbManager.addAuditLog(orgId, actor.name, actor.role, 'NUEVA_INSPECCION', 'Inspecciones', `Completada inspección "${title}" con score ${score}/100`);
    dbManager.save();
    res.status(201).json(newInspection);
  });

  app.get('/api/corrective-actions', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const list = db.correctiveActions.filter(c => c.organizationId === orgId);
    res.json(list);
  });

  app.post('/api/corrective-actions', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const { facilityId, title, findingDescription, rootCause, proposedAction, responsible, deadline } = req.body;

    if (!title || !proposedAction || !deadline) {
      return res.status(400).json({ error: 'Título, acción propuesta y fecha límite son obligatorios.' });
    }

    const db = dbManager.get();
    const newCapa = {
      id: `capa-${Date.now()}`,
      organizationId: orgId,
      facilityId: facilityId || db.facilities.find(f => f.organizationId === orgId)?.id || '',
      title,
      findingDescription: findingDescription || 'Hallazgo formulado en inspección interna',
      rootCause: rootCause || 'Por determinar',
      proposedAction,
      responsible: responsible || actor.name,
      deadline,
      status: 'abierta' as const
    };

    db.correctiveActions.push(newCapa);
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'CREACION_CAPA', 'Acciones Correctivas', `Creada acción correctiva: "${title}"`);
    dbManager.save();
    res.status(201).json(newCapa);
  });

  app.put('/api/corrective-actions/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const db = dbManager.get();
    const idx = db.correctiveActions.findIndex(c => c.id === id && c.organizationId === orgId);

    if (idx === -1) return res.status(404).json({ error: 'Acción no encontrada.' });

    const updated = { ...db.correctiveActions[idx], ...req.body };
    db.correctiveActions[idx] = updated;
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'ACTUALIZACION_CAPA', 'Acciones Correctivas', `Actualizada acción CAPA "${updated.title}" a: ${updated.status}`);
    dbManager.save();
    res.json(updated);
  });

  // 9. Document Library
  app.get('/api/documents', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const list = db.documents.filter(d => d.organizationId === orgId);
    res.json(list);
  });

  app.post('/api/documents', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const { title, category, facilityId, obligationId, fileName, fileSizeKb, version } = req.body;

    if (!title || !fileName) {
      return res.status(400).json({ error: 'Título del documento y nombre de archivo son obligatorios.' });
    }

    const db = dbManager.get();
    const newDoc = {
      id: `doc-${Date.now()}`,
      organizationId: orgId,
      facilityId: facilityId || undefined,
      obligationId: obligationId || undefined,
      title,
      category: category || 'monitoreo',
      fileName,
      fileSizeKb: fileSizeKb ? Number(fileSizeKb) : Math.floor(Math.random() * 2000) + 300,
      uploadDate: new Date().toISOString().split('T')[0],
      version: version || '1.0',
      uploadedBy: actor.name
    };

    db.documents.push(newDoc);

    // If linked to an obligation, increment obligation evidence count
    if (obligationId) {
      const ob = db.obligations.find(o => o.id === obligationId);
      if (ob) ob.evidenceCount = (ob.evidenceCount || 0) + 1;
    }

    dbManager.addAuditLog(orgId, actor.name, actor.role, 'CARGA_DOCUMENTO', 'Documentos', `Cargado documento ambiental: ${fileName} (${title})`);
    dbManager.save();
    res.status(201).json(newDoc);
  });

  app.delete('/api/documents/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const idx = db.documents.findIndex(d => d.id === id && d.organizationId === orgId);
    if (idx === -1) return res.status(404).json({ error: 'Documento no encontrado.' });
    db.documents.splice(idx, 1);
    dbManager.save();
    res.json({ success: true });
  });

  // 10. Dashboard & Analytics Consolidated API
  app.get('/api/analytics/dashboard', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();

    const facilities = db.facilities.filter(f => f.organizationId === orgId);
    const obligations = db.obligations.filter(o => o.organizationId === orgId);
    const waste = db.wasteRecords.filter(w => w.organizationId === orgId);
    const water = db.waterRecords.filter(w => w.organizationId === orgId);
    const air = db.airRecords.filter(a => a.organizationId === orgId);
    const energy = db.energyRecords.filter(e => e.organizationId === orgId);
    const inspections = db.inspections.filter(i => i.organizationId === orgId);
    const correctiveActions = db.correctiveActions.filter(c => c.organizationId === orgId);
    const documents = db.documents.filter(d => d.organizationId === orgId);

    const compMetrics = calculateComplianceRate(obligations);
    const wasteMetrics = aggregateWasteMetrics(waste);
    const waterMetrics = aggregateWaterMetrics(water);
    const airMetrics = evaluateAirCompliance(air);
    const energyMetrics = calculateEnergyIntensity(energy);

    // Upcoming obligations sorted by due date
    const upcomingObligations = [...obligations]
      .sort((a, b) => a.dueDate.localeCompare(b.dueDate))
      .slice(0, 6);

    res.json({
      organization: db.organizations.find(o => o.id === orgId),
      counts: {
        facilities: facilities.length,
        obligations: obligations.length,
        inspections: inspections.length,
        openActions: correctiveActions.filter(a => a.status === 'abierta' || a.status === 'en_implementacion').length,
        documents: documents.length
      },
      compliance: compMetrics,
      waste: wasteMetrics,
      water: waterMetrics,
      air: airMetrics,
      energy: energyMetrics,
      upcomingObligations,
      recentInspections: inspections.slice(-3),
      recentActions: correctiveActions.slice(-3)
    });
  });

  // Export CSV
  app.get('/api/reports/export-csv', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const { module: targetModule } = req.query;
    const db = dbManager.get();

    let csvContent = '';
    let fileName = `ecoinntelligence_export_${targetModule || 'general'}.csv`;

    if (targetModule === 'residuos') {
      const records = db.wasteRecords.filter(w => w.organizationId === orgId);
      csvContent = 'ID,Fecha,Instalación,Residuo,Categoría,Cantidad_kg,Proceso_Origen,Transportista,Destino,Tratamiento,Manifiesto\n';
      for (const r of records) {
        csvContent += `"${r.id}","${r.date}","${r.facilityId}","${r.wasteName}","${r.category}",${r.quantityKg},"${r.originProcess}","${r.carrier}","${r.destination}","${r.treatmentType}","${r.manifestNumber || ''}"\n`;
      }
    } else if (targetModule === 'cumplimiento') {
      const records = db.obligations.filter(o => o.organizationId === orgId);
      csvContent = 'ID,Título,Fuente_Normativa,Jurisdicción,Vencimiento,Frecuencia,Responsable,Estado,Evidencias\n';
      for (const r of records) {
        csvContent += `"${r.id}","${r.title}","${r.normativeSource}","${r.jurisdiction}","${r.dueDate}","${r.frequency}","${r.responsible}","${r.status}",${r.evidenceCount}\n`;
      }
    } else {
      // General environmental KPI summary
      const comp = calculateComplianceRate(db.obligations.filter(o => o.organizationId === orgId));
      const w = aggregateWasteMetrics(db.wasteRecords.filter(w => w.organizationId === orgId));
      const wt = aggregateWaterMetrics(db.waterRecords.filter(w => w.organizationId === orgId));
      const en = calculateEnergyIntensity(db.energyRecords.filter(e => e.organizationId === orgId));

      csvContent = 'Métrica,Valor,Unidad,Estado\n';
      csvContent += `Tasa de Cumplimiento Legal,${comp.complianceRatePercent},%,"${comp.complianceRatePercent >= 80 ? 'Conforme' : 'Atención'}"\n`;
      csvContent += `Total Residuos Generados,${w.totalKg},kg,Monitoreado\n`;
      csvContent += `Residuos Peligrosos,${w.hazardousKg},kg,Custodia Ambiental\n`;
      csvContent += `Consumo de Agua,${wt.totalConsumedM3},m3,Operación Normal\n`;
      csvContent += `Consumo Energético Total,${en.totalKWh},kWh,Eficiencia\n`;
      csvContent += `Participación Renovable,${en.renewableSharePercent},%,Objetivo ESG\n`;
      csvContent += `Emisiones CO2e Estimadas,${en.estimatedCo2Ton},tCO2e,Huella Carbono\n`;
    }

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    res.send('\uFEFF' + csvContent); // UTF-8 BOM for Excel
  });

  // 11. Deterministic Intelligent Assistant
  app.post('/api/assistant/query', (req: Request, res: Response) => {
    const { query } = req.body;
    if (!query || typeof query !== 'string') {
      return res.status(400).json({ error: 'La consulta no puede estar vacía.' });
    }

    const orgId = getContextOrgId(req);
    const db = dbManager.get();

    const context = {
      obligations: db.obligations.filter(o => o.organizationId === orgId),
      waste: db.wasteRecords.filter(w => w.organizationId === orgId),
      water: db.waterRecords.filter(w => w.organizationId === orgId),
      air: db.airRecords.filter(a => a.organizationId === orgId),
      energy: db.energyRecords.filter(e => e.organizationId === orgId),
      actions: db.correctiveActions.filter(c => c.organizationId === orgId)
    };

    const answer = answerEnvironmentalQuery(query, context);
    res.json(answer);
  });

  // 12. Audit Logs
  app.get('/api/audit-logs', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const logs = db.auditLogs.filter(l => l.organizationId === orgId);
    res.json(logs);
  });

  // 13. Billing & SaaS Quotas
  app.get('/api/billing/subscription', (req: Request, res: Response) => {
    const orgId = getContextOrgId(req);
    const db = dbManager.get();
    const org = db.organizations.find(o => o.id === orgId) || db.organizations[0];
    const currentPlan = db.subscriptions[org.plan] || db.subscriptions.pro;

    const facilitiesCount = db.facilities.filter(f => f.organizationId === orgId).length;
    const usersCount = db.users.filter(u => u.organizationId === orgId).length;
    const documents = db.documents.filter(d => d.organizationId === orgId);
    const usedStorageMb = Math.round(documents.reduce((acc, d) => acc + (d.fileSizeKb / 1024), 0) * 10) / 10;

    res.json({
      currentPlan,
      usage: {
        facilitiesCount,
        maxFacilities: currentPlan.maxFacilities,
        facilitiesPercent: Math.round((facilitiesCount / currentPlan.maxFacilities) * 100),
        usersCount,
        maxUsers: currentPlan.maxUsers,
        usersPercent: Math.round((usersCount / currentPlan.maxUsers) * 100),
        usedStorageMb,
        maxStorageMb: currentPlan.maxStorageMb,
        storagePercent: Math.round((usedStorageMb / currentPlan.maxStorageMb) * 100)
      },
      allPlans: db.subscriptions
    });
  });

  app.post('/api/billing/change-plan', (req: Request, res: Response) => {
    const { planId } = req.body;
    const orgId = getContextOrgId(req);
    const actor = getActorInfo(req);
    const db = dbManager.get();

    const org = db.organizations.find(o => o.id === orgId);
    if (!org) return res.status(404).json({ error: 'Organización no encontrada.' });

    if (!db.subscriptions[planId]) {
      return res.status(400).json({ error: 'Plan seleccionado no existe.' });
    }

    org.plan = planId;
    dbManager.addAuditLog(orgId, actor.name, actor.role, 'CAMBIO_PLAN_SAAS', 'Suscripción', `Plan actualizado a: ${db.subscriptions[planId].planName}`);
    dbManager.save();

    res.json({ success: true, updatedPlan: db.subscriptions[planId] });
  });

  // System reset endpoint to restore clean laboratory database
  app.post('/api/system/reset-seed', (req: Request, res: Response) => {
    const restored = dbManager.resetToLaboratorySeed();
    res.json({ success: true, message: 'Base de datos restaurada al dataset de laboratorio inicial con migraciones 001-038.' });
  });

  // Integrate Vite dev server or static files
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ECOINTELLIGENCE server running at http://0.0.0.0:${PORT} in ${isProd ? 'production' : 'development'} mode.`);
  });
}

startServer().catch(err => {
  console.error('Failed to start ECOINTELLIGENCE server:', err);
  process.exit(1);
});
