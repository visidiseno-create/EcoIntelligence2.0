import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../../data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

export interface Organization {
  id: string;
  name: string;
  taxId: string; // RUC / RFC / CIF
  sector: string;
  country: string;
  plan: 'starter' | 'pro' | 'enterprise';
  createdAt: string;
}

export interface Facility {
  id: string;
  organizationId: string;
  name: string;
  code: string;
  address: string;
  coordinates: { lat: number; lng: number };
  activity: string;
  environmentalPermitCode: string;
  status: 'activa' | 'en_mantenimiento' | 'inactiva';
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'auditor' | 'operador' | 'lector';
  organizationId: string;
  facilityIds: string[];
}

export interface DocumentItem {
  id: string;
  organizationId: string;
  facilityId?: string;
  obligationId?: string;
  title: string;
  category: 'licencia' | 'monitoreo' | 'manifiesto' | 'politica' | 'auditoria';
  fileName: string;
  fileSizeKb: number;
  uploadDate: string;
  version: string;
  uploadedBy: string;
  fileContentBase64?: string;
}

export interface InspectionTemplate {
  id: string;
  title: string;
  sector: string;
  categories: Array<{
    name: string;
    items: string[];
  }>;
}

export interface Inspection {
  id: string;
  organizationId: string;
  facilityId: string;
  templateId: string;
  title: string;
  date: string;
  inspector: string;
  status: 'completada' | 'en_progreso' | 'programada';
  score: number;
  summary: string;
  findings: Array<{
    id: string;
    type: 'no_conformidad_mayor' | 'no_conformidad_menor' | 'oportunidad_mejora';
    description: string;
    area: string;
    actionRequired: boolean;
  }>;
}

export interface CorrectiveAction {
  id: string;
  organizationId: string;
  facilityId: string;
  inspectionId?: string;
  title: string;
  findingDescription: string;
  rootCause: string;
  proposedAction: string;
  responsible: string;
  deadline: string;
  status: 'abierta' | 'en_implementacion' | 'en_verificacion' | 'cerrada';
  closureEvidence?: string;
}

export interface AuditLog {
  id: string;
  organizationId: string;
  timestamp: string;
  userName: string;
  userRole: string;
  action: string;
  module: string;
  details: string;
}

export interface SubscriptionQuota {
  planId: 'starter' | 'pro' | 'enterprise';
  planName: string;
  monthlyPriceUsd: number;
  maxFacilities: number;
  maxUsers: number;
  maxStorageMb: number;
  features: string[];
}

export interface DatabaseSchema {
  organizations: Organization[];
  facilities: Facility[];
  users: User[];
  obligations: any[];
  wasteRecords: any[];
  waterRecords: any[];
  airRecords: any[];
  energyRecords: any[];
  inspectionTemplates: InspectionTemplate[];
  inspections: Inspection[];
  correctiveActions: CorrectiveAction[];
  documents: DocumentItem[];
  auditLogs: AuditLog[];
  subscriptions: Record<string, SubscriptionQuota>;
}

// Initial Seed Data representing migrations 001-038
const INITIAL_DATABASE: DatabaseSchema = {
  organizations: [
    {
      id: 'org-1',
      name: 'BioAndes Agroindustria S.A.C.',
      taxId: '20549812401',
      sector: 'Agroindustria y Procesamiento de Alimentos',
      country: 'Perú',
      plan: 'pro',
      createdAt: '2025-01-15'
    },
    {
      id: 'org-2',
      name: 'MetalMecánica del Pacífico S.A.',
      taxId: '20108745912',
      sector: 'Metalmecánica, Fundición y Galvanoplastia',
      country: 'Perú',
      plan: 'enterprise',
      createdAt: '2025-03-20'
    }
  ],
  facilities: [
    {
      id: 'fac-1',
      organizationId: 'org-1',
      name: 'Planta Principal Lurín',
      code: 'PLT-LUR-01',
      address: 'Km 37.5 Antigua Panamericana Sur, Lurín, Lima',
      coordinates: { lat: -12.2748, lng: -76.8711 },
      activity: 'Extracción de aceites esenciales y envasado de concentrados',
      environmentalPermitCode: 'DIA-PRODUCE-2023-049',
      status: 'activa'
    },
    {
      id: 'fac-2',
      organizationId: 'org-1',
      name: 'Complejo Agroindustrial Ica',
      code: 'CMP-ICA-02',
      address: 'Valle de Villacurí Sublote 14, Salas Guadalupe, Ica',
      coordinates: { lat: -13.9852, lng: -75.7612 },
      activity: 'Packing y deshidratado solar de frutas de exportación',
      environmentalPermitCode: 'EIA-sd-MIDAGRI-2022-118',
      status: 'activa'
    },
    {
      id: 'fac-3',
      organizationId: 'org-1',
      name: 'Centro de Distribución Huachipa',
      code: 'CD-HUA-03',
      address: 'Av. Las Torres 450, Huachipa, Lurigancho, Lima',
      coordinates: { lat: -12.0124, lng: -76.9205 },
      activity: 'Almacenamiento en frío y logística refrigerada',
      environmentalPermitCode: 'ITS-PRODUCE-2024-002',
      status: 'activa'
    },
    {
      id: 'fac-4',
      organizationId: 'org-2',
      name: 'Fundición y Laminación Callao',
      code: 'FND-CAL-01',
      address: 'Av. Néstor Gambetta Km 6.8, Callao',
      coordinates: { lat: -11.9984, lng: -77.1324 },
      activity: 'Fundición continua de piezas de bronce y aleaciones',
      environmentalPermitCode: 'EIA-d-MINEM-2021-085',
      status: 'activa'
    },
    {
      id: 'fac-5',
      organizationId: 'org-2',
      name: 'Planta de Galvanizado Ventanilla',
      code: 'GLV-VEN-02',
      address: 'Zona Industrial Parque Porcino Mz. B, Ventanilla',
      coordinates: { lat: -11.8741, lng: -77.1298 },
      activity: 'Baños de zincado por inmersión en caliente',
      environmentalPermitCode: 'PAMA-PRODUCE-2020-034',
      status: 'activa'
    }
  ],
  users: [
    {
      id: 'usr-1',
      email: 'admin@ecoinntelligence.com',
      name: 'Ing. Valeria Mendoza',
      role: 'admin',
      organizationId: 'org-1',
      facilityIds: ['fac-1', 'fac-2', 'fac-3']
    },
    {
      id: 'usr-2',
      email: 'auditor@ecoinntelligence.com',
      name: 'Dr. Roberto Santillán',
      role: 'auditor',
      organizationId: 'org-1',
      facilityIds: ['fac-1', 'fac-2', 'fac-3']
    },
    {
      id: 'usr-3',
      email: 'operador@ecoinntelligence.com',
      name: 'Tec. Carlos Paredes',
      role: 'operador',
      organizationId: 'org-1',
      facilityIds: ['fac-1']
    },
    {
      id: 'usr-4',
      email: 'lector@ecoinntelligence.com',
      name: 'Lic. Andrea Benavides',
      role: 'lector',
      organizationId: 'org-1',
      facilityIds: ['fac-1', 'fac-2', 'fac-3']
    }
  ],
  obligations: [
    {
      id: 'ob-101',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      title: 'Monitoreo Ambiental Trimestral de Calidad de Aire y Emisiones',
      normativeSource: 'D.S. 003-2017-MINAM & Compromiso EIA DIA-049',
      jurisdiction: 'Nacional / MINAM - OEFA',
      dueDate: '2026-11-15',
      frequency: 'trimestral',
      responsible: 'Ing. Valeria Mendoza',
      status: 'en_progreso',
      evidenceCount: 3,
      description: 'Monitoreo de material particulado PM10 y gases de combustión en chimenea de caldera por laboratorio acreditado INACAL.'
    },
    {
      id: 'ob-102',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      title: 'Declaración Anual de Manejo de Residuos Sólidos (SIGERSOL)',
      normativeSource: 'D.L. 1278 - Ley de Gestión Integral de Residuos Sólidos',
      jurisdiction: 'Nacional / MINAM',
      dueDate: '2026-11-28',
      frequency: 'anual',
      responsible: 'Tec. Carlos Paredes',
      status: 'pendiente',
      evidenceCount: 1,
      description: 'Presentación formal en plataforma SIGERSOL con consolidado de manifiestos de residuos peligrosos y no peligrosos.'
    },
    {
      id: 'ob-103',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      title: 'Monitoreo y Registro de Caudales de Extracción de Aguas Subterráneas',
      normativeSource: 'R.J. 007-2020-ANA (Autoridad Nacional del Agua)',
      jurisdiction: 'Sectorial / ANA - ALA Ica',
      dueDate: '2026-10-31',
      frequency: 'mensual',
      responsible: 'Ing. Valeria Mendoza',
      status: 'vencida',
      evidenceCount: 0,
      description: 'Remisión de reportes mensuales de horómetro y caudalímetros de los pozos IRHS-45 e IRHS-46 a la Autoridad Local del Agua.'
    },
    {
      id: 'ob-104',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      title: 'Renovación de Póliza de Seguro Ambiental para Sustancias Peligrosas',
      normativeSource: 'Ley 28611 Ley General del Ambiente Art. 147',
      jurisdiction: 'Nacional',
      dueDate: '2026-12-10',
      frequency: 'anual',
      responsible: 'Lic. Andrea Benavides',
      status: 'en_progreso',
      evidenceCount: 1,
      description: 'Contratación y entrega a OEFA de la póliza de responsabilidad civil por contaminación ambiental para el parque de solventes.'
    },
    {
      id: 'ob-105',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      title: 'Actualización del Plan de Contingencias Ambientales y Simulacro de Derrames',
      normativeSource: 'D.S. 017-2015-PRODUCE',
      jurisdiction: 'Sectorial / PRODUCE',
      dueDate: '2026-11-02',
      frequency: 'semestral',
      responsible: 'Ing. Valeria Mendoza',
      status: 'cumplida',
      evidenceCount: 4,
      description: 'Ejecución del simulacro semestral de fuga de amoníaco y derrame de combustible con acta de veeduría y registro fotográfico.'
    },
    {
      id: 'ob-106',
      organizationId: 'org-1',
      facilityId: 'fac-3',
      title: 'Calibración de Detectores de Refrigerantes Hidrofluorocarbonados (HFC)',
      normativeSource: 'Protocolo de Montreal & Enmienda de Kigali',
      jurisdiction: 'Internacional / PRODUCE',
      dueDate: '2026-12-05',
      frequency: 'semestral',
      responsible: 'Tec. Carlos Paredes',
      status: 'pendiente',
      evidenceCount: 0,
      description: 'Certificado de calibración de los 12 sensores de fuga en cámaras de congelación profunda.'
    }
  ],
  wasteRecords: [
    {
      id: 'w-201',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-11-01',
      wasteName: 'Lodos deshidratados de PTAR',
      category: 'peligroso',
      quantityKg: 1450,
      originProcess: 'Planta de Tratamiento de Efluentes Industriales',
      carrier: 'TransAmbiental Perú S.A.C.',
      destination: 'Relleno de Seguridad Huaycoloro (Petramás)',
      treatmentType: 'disposicion_final',
      manifestNumber: 'MAN-2026-0891'
    },
    {
      id: 'w-202',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-11-02',
      wasteName: 'Aceites dieléctricos y lubricantes usados',
      category: 'peligroso',
      quantityKg: 320,
      originProcess: 'Mantenimiento Preventivo de Reductores',
      carrier: 'OilTech Soluciones Ambientales',
      destination: 'Planta de Re-refinación Ecológica',
      treatmentType: 'reciclaje',
      manifestNumber: 'MAN-2026-0892'
    },
    {
      id: 'w-203',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-11-03',
      wasteName: 'Envases plásticos de polietileno triple lavado',
      category: 'reciclable',
      quantityKg: 840,
      originProcess: 'Línea de Dosificación de Nutrientes',
      carrier: 'CampoLimpio Perú',
      destination: 'Planta de Extrusión Plástica Industrial',
      treatmentType: 'reciclaje',
      manifestNumber: 'MAN-2026-0893'
    },
    {
      id: 'w-204',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      date: '2026-11-03',
      wasteName: 'Restos de poda y pulpa vegetal agroindustrial',
      category: 'organico',
      quantityKg: 5200,
      originProcess: 'Selección y Despalillado en Packing',
      carrier: 'AgroCompost Ica E.I.R.L.',
      destination: 'Pila de Compostaje Fundo Los Álamos',
      treatmentType: 'compostaje',
      manifestNumber: 'MAN-2026-0894'
    },
    {
      id: 'w-205',
      organizationId: 'org-1',
      facilityId: 'fac-3',
      date: '2026-11-04',
      wasteName: 'Baterías de montacargas de plomo-ácido en desuso',
      category: 'raee',
      quantityKg: 680,
      originProcess: 'Taller Eléctrico Centro de Distribución',
      carrier: 'Baterías Rápido Reciclaje',
      destination: 'Planta Metalúrgica de Recuperación de Plomo',
      treatmentType: 'reciclaje',
      manifestNumber: 'MAN-2026-0895'
    }
  ],
  waterRecords: [
    {
      id: 'wt-301',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-10-28',
      source: 'red_publica',
      volumeConsumedM3: 620,
      volumeDischargedM3: 410,
      dischargePermitCompliant: true,
      bod5MgL: 42, // DBO5
      codMgL: 85,  // DQO
      ph: 7.2
    },
    {
      id: 'wt-302',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-11-02',
      source: 'agua_recirculada',
      volumeConsumedM3: 280,
      volumeDischargedM3: 0,
      dischargePermitCompliant: true,
      bod5MgL: 12,
      codMgL: 28,
      ph: 7.0
    },
    {
      id: 'wt-303',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      date: '2026-10-30',
      source: 'pozo_subterraneo',
      volumeConsumedM3: 1450,
      volumeDischargedM3: 980,
      dischargePermitCompliant: true,
      bod5MgL: 38,
      codMgL: 76,
      ph: 7.4
    },
    {
      id: 'wt-304',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      date: '2026-11-03',
      source: 'fuente_superficial',
      volumeConsumedM3: 890,
      volumeDischargedM3: 610,
      dischargePermitCompliant: false, // High TSS trigger
      bod5MgL: 75,
      codMgL: 160,
      ph: 8.6
    }
  ],
  airRecords: [
    {
      id: 'air-401',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-10-25',
      emissionSource: 'Chimenea Caldera Pirotubular 150 BHP (CH-01)',
      parameter: 'PM10',
      measuredValue: 48.5,
      limitValue: 50.0,
      unit: 'mg/Nm3'
    },
    {
      id: 'air-402',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-10-25',
      emissionSource: 'Chimenea Caldera Pirotubular 150 BHP (CH-01)',
      parameter: 'SO2',
      measuredValue: 142.0,
      limitValue: 200.0,
      unit: 'mg/Nm3'
    },
    {
      id: 'air-403',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-10-26',
      emissionSource: 'Chimenea Caldera Pirotubular 150 BHP (CH-01)',
      parameter: 'NOx',
      measuredValue: 210.0,
      limitValue: 250.0,
      unit: 'mg/Nm3'
    },
    {
      id: 'air-404',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-10-27',
      emissionSource: 'Horno Deshidratador de Frutas (HD-02)',
      parameter: 'CO',
      measuredValue: 185.0,
      limitValue: 150.0, // Exceeded!
      unit: 'mg/Nm3'
    },
    {
      id: 'air-405',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      date: '2026-11-01',
      emissionSource: 'Generador Eléctrico de Emergencia Cummins 500kVA',
      parameter: 'PM2.5',
      measuredValue: 22.4,
      limitValue: 25.0,
      unit: 'mg/Nm3'
    }
  ],
  energyRecords: [
    {
      id: 'en-501',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-10-25',
      sourceType: 'red_electrica',
      consumptionKWh: 18500,
      costUsd: 2220
    },
    {
      id: 'en-502',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-10-25',
      sourceType: 'solar_fotovoltaica',
      consumptionKWh: 6200,
      costUsd: 0
    },
    {
      id: 'en-503',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      date: '2026-10-26',
      sourceType: 'gas_natural',
      consumptionKWh: 12400,
      costUsd: 890
    },
    {
      id: 'en-504',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      date: '2026-10-28',
      sourceType: 'red_electrica',
      consumptionKWh: 24000,
      costUsd: 2880
    },
    {
      id: 'en-505',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      date: '2026-10-28',
      sourceType: 'solar_fotovoltaica',
      consumptionKWh: 9500,
      costUsd: 0
    },
    {
      id: 'en-506',
      organizationId: 'org-1',
      facilityId: 'fac-3',
      date: '2026-11-01',
      sourceType: 'diesel',
      consumptionKWh: 3800,
      costUsd: 1140
    }
  ],
  inspectionTemplates: [
    {
      id: 'tmpl-1',
      title: 'Auditoría Ambiental de Cumplimiento Legal e Instalaciones Industriales',
      sector: 'Industria Manufacturera y Agroindustria',
      categories: [
        {
          name: 'Almacenamiento de Sustancias Peligrosas y Combustibles',
          items: [
            '¿Cuentan los tanques y cilindros con cubeto de retención secundaria con capacidad >= 110%?',
            '¿Se encuentran las hojas de datos de seguridad (FDS/MSDS) en idioma español y accesibles en el punto de uso?',
            '¿Se dispone de kit antiderrame completo (cordones absorbentes, paños, EPP y bandeja receptora)?'
          ]
        },
        {
          name: 'Gestión Integral de Residuos Sólidos',
          items: [
            '¿El almacén central de residuos cuenta con techado, ventilación, piso impermeable y señalización reglamentaria?',
            '¿Los cilindros están rotulados según la NTP 900.058 (código de colores) con fecha de inicio de almacenamiento?',
            '¿Se cuenta con manifiestos de residuos peligrosos firmados por el operador y la planta de disposición final?'
          ]
        },
        {
          name: 'Manejo de Efluentes y Emisiones',
          items: [
            '¿La planta de tratamiento de efluentes cuenta con bitácora diaria de operación y medición de parámetros in situ?',
            '¿Los puntos de muestreo en chimeneas cuentan con plataforma segura y puertos normalizados según EPA Método 1?'
          ]
        }
      ]
    },
    {
      id: 'tmpl-2',
      title: 'Inspección de Seguridad Hídrica y Monitoreo de Pozos',
      sector: 'Agroexportación',
      categories: [
        {
          name: 'Monitoreo de Extracción de Pozo',
          items: [
            '¿El caudalímetro volumétrico se encuentra precintado y con certificado de calibración vigente?',
            '¿Se realiza la medición estática y dinámica del nivel freático con sonda piezométrica?'
          ]
        }
      ]
    }
  ],
  inspections: [
    {
      id: 'insp-601',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      templateId: 'tmpl-1',
      title: 'Inspección Trimestral de Almacén de Químicos y PTAR',
      date: '2026-10-22',
      inspector: 'Dr. Roberto Santillán (Auditor Líder)',
      status: 'completada',
      score: 84,
      summary: 'Instalaciones en buen estado operativo general. Se identificaron 2 no conformidades menores relativas a etiquetado y falta de bandeja antiderrame temporal.',
      findings: [
        {
          id: 'fnd-01',
          type: 'no_conformidad_menor',
          description: 'Cilindros de lubricante ISO 68 sin rotulación de código NFPA 704 en zona de mantenimiento auxiliar.',
          area: 'Taller de Mantenimiento',
          actionRequired: true
        },
        {
          id: 'fnd-02',
          type: 'oportunidad_mejora',
          description: 'Optimizar la periodicidad de purga de lodos del sedimentador secundario para evitar picos de DBO5.',
          area: 'PTAR Industrial',
          actionRequired: false
        }
      ]
    },
    {
      id: 'insp-602',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      templateId: 'tmpl-2',
      title: 'Auditoría de Pozos Subterráneos y Riego Presurizado',
      date: '2026-11-02',
      inspector: 'Ing. Valeria Mendoza',
      status: 'completada',
      score: 92,
      summary: 'Mediciones de caudalímetros en regla y en concordancia con la cuota de extracción asignada por la Autoridad Local del Agua.',
      findings: [
        {
          id: 'fnd-03',
          type: 'oportunidad_mejora',
          description: 'Implementar telemetría LoRaWAN en pozo IRHS-46 para automatizar el envío de lecturas horarias.',
          area: 'Estación de Bombeo 2',
          actionRequired: false
        }
      ]
    }
  ],
  correctiveActions: [
    {
      id: 'capa-701',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      inspectionId: 'insp-601',
      title: 'Implementación de Bandeja de Contención y Rotulación NFPA en Lubricantes',
      findingDescription: 'Cilindros de lubricante ISO 68 sin rotulación de código NFPA 704 en zona de mantenimiento auxiliar.',
      rootCause: 'Falta de procedimiento estandarizado para recepción y rotulado previo al ingreso al almacén satélite.',
      proposedAction: 'Comprar 2 bandejas de polietileno de alta densidad (HDPE) de 4 tambores y reetiquetar el 100% de los envases con código diamante.',
      responsible: 'Tec. Carlos Paredes',
      deadline: '2026-11-20',
      status: 'en_implementacion',
      closureEvidence: 'OC-2026-441 emitida para compra de bandejas Justrite.'
    },
    {
      id: 'capa-702',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      title: 'Calibración de Quemador en Caldera CH-01 por Monóxido de Carbono (CO)',
      findingDescription: 'Lectura de CO en chimenea alcanzó 185 mg/Nm3, superando el límite referencial de 150 mg/Nm3.',
      rootCause: 'Relación aire-combustible descalibrada y acumulación de hollín en toberas de inyección.',
      proposedAction: 'Servicio técnico especializado de regulación de quemador Weishaupt y análisis de gases en caliente.',
      responsible: 'Ing. Valeria Mendoza',
      deadline: '2026-11-18',
      status: 'abierta'
    },
    {
      id: 'capa-703',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      title: 'Adecuación de Válvula Check en Cabezal de Pozo IRHS-45',
      findingDescription: 'Retorno de contraflujo observado durante paradas imprevistas del sistema.',
      rootCause: 'Desgaste en asiento de teflón de la válvula retención instalada en 2021.',
      proposedAction: 'Reemplazo preventivo de válvula de retención dúctil de 6 pulgadas con prueba hidrostática.',
      responsible: 'Jefe de Mantenimiento Ica',
      deadline: '2026-10-30',
      status: 'cerrada',
      closureEvidence: 'Informe técnico de instalación N° 088 y acta de conformidad firmada.'
    }
  ],
  documents: [
    {
      id: 'doc-801',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      obligationId: 'ob-101',
      title: 'Informe de Ensayo Acreditado de Emisiones Atmosféricas - Trimestre III',
      category: 'monitoreo',
      fileName: 'INFORME_MONITOREO_AIRE_CH01_Q3_2026.pdf',
      fileSizeKb: 1420,
      uploadDate: '2026-10-28',
      version: '1.0',
      uploadedBy: 'Ing. Valeria Mendoza'
    },
    {
      id: 'doc-802',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      title: 'Declaración de Impacto Ambiental (DIA) Aprobada R.D. 049-2023-PRODUCE',
      category: 'licencia',
      fileName: 'RESOLUCION_DIRECTORAL_DIA_LURIN.pdf',
      fileSizeKb: 3840,
      uploadDate: '2025-02-10',
      version: 'Oficial',
      uploadedBy: 'Gerencia Legal'
    },
    {
      id: 'doc-803',
      organizationId: 'org-1',
      facilityId: 'fac-1',
      obligationId: 'ob-102',
      title: 'Manifiesto de Residuos Peligrosos N° 2026-0891 - Lodos PTAR',
      category: 'manifiesto',
      fileName: 'MANIFIESTO_SIGERSOL_LODOS_0891.pdf',
      fileSizeKb: 650,
      uploadDate: '2026-11-01',
      version: '1.0',
      uploadedBy: 'Tec. Carlos Paredes'
    },
    {
      id: 'doc-804',
      organizationId: 'org-1',
      facilityId: 'fac-2',
      obligationId: 'ob-105',
      title: 'Plan de Contingencias Ambientales y Respuesta a Emergencias 2026',
      category: 'politica',
      fileName: 'PLAN_CONTINGENCIAS_ICA_REV4.pdf',
      fileSizeKb: 2150,
      uploadDate: '2026-06-15',
      version: '4.0',
      uploadedBy: 'Ing. Valeria Mendoza'
    }
  ],
  auditLogs: [
    {
      id: 'aud-901',
      organizationId: 'org-1',
      timestamp: '2026-11-04 18:32:10',
      userName: 'Ing. Valeria Mendoza',
      userRole: 'admin',
      action: 'CREACION_REGISTRO',
      module: 'Residuos',
      details: 'Registrado manifiesto de lodos PTAR (1,450 kg) en Planta Lurín.'
    },
    {
      id: 'aud-902',
      organizationId: 'org-1',
      timestamp: '2026-11-04 19:15:42',
      userName: 'Dr. Roberto Santillán',
      userRole: 'auditor',
      action: 'CIERRE_INSPECCION',
      module: 'Inspecciones',
      details: 'Concluida inspección trimestral con score 84/100 y 2 hallazgos formulados.'
    },
    {
      id: 'aud-903',
      organizationId: 'org-1',
      timestamp: '2026-11-04 19:50:00',
      userName: 'Tec. Carlos Paredes',
      userRole: 'operador',
      action: 'ACTUALIZACION_ESTADO',
      module: 'Acciones Correctivas',
      details: 'Actualizada acción CAPA-701 a estado "En Implementación".'
    }
  ],
  subscriptions: {
    starter: {
      planId: 'starter',
      planName: 'Starter Eco',
      monthlyPriceUsd: 149,
      maxFacilities: 1,
      maxUsers: 3,
      maxStorageMb: 500,
      features: [
        'Gestión de 1 Instalación',
        'Matriz de Obligaciones Ambientales',
        'Registro de Residuos y Agua',
        'Exportación CSV estándar',
        'Soporte por correo'
      ]
    },
    pro: {
      planId: 'pro',
      planName: 'Pro Compliance & ESG',
      monthlyPriceUsd: 490,
      maxFacilities: 5,
      maxUsers: 15,
      maxStorageMb: 5000,
      features: [
        'Hasta 5 Instalaciones multi-sede',
        'Gestión completa de Aire, Residuos, Agua y Energía',
        'Inspecciones en campo y módulo CAPA',
        'Biblioteca de Evidencias y Documentos',
        'Generación de Informes Ejecutivos PDF oficiales',
        'Asistente de Inteligencia Ambiental Determinístico',
        'Trazabilidad y Auditoría de Permisos (RBAC)'
      ]
    },
    enterprise: {
      planId: 'enterprise',
      planName: 'Enterprise Multi-Plant',
      monthlyPriceUsd: 1200,
      maxFacilities: 25,
      maxUsers: 100,
      maxStorageMb: 50000,
      features: [
        'Instalaciones y sedes ilimitadas',
        'Usuarios ilimitados con roles personalizados',
        'Integraciones API directas',
        'Gestor de cuenta y soporte 24/7',
        'Auditorías consolidadas para corporativos internacionales'
      ]
    }
  }
};

class DatabaseManager {
  private db: DatabaseSchema;

  constructor() {
    this.ensureDataDir();
    this.db = this.load();
  }

  private ensureDataDir() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private load(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error('Error loading db.json, initializing default:', e);
    }
    this.save(INITIAL_DATABASE);
    return JSON.parse(JSON.stringify(INITIAL_DATABASE));
  }

  public save(data?: DatabaseSchema) {
    if (data) {
      this.db = data;
    }
    this.ensureDataDir();
    fs.writeFileSync(DB_FILE, JSON.stringify(this.db, null, 2), 'utf-8');
  }

  public get(): DatabaseSchema {
    return this.db;
  }

  public resetToLaboratorySeed() {
    this.db = JSON.parse(JSON.stringify(INITIAL_DATABASE));
    this.save();
    return this.db;
  }

  public addAuditLog(organizationId: string, userName: string, userRole: string, action: string, module: string, details: string) {
    const log: AuditLog = {
      id: `aud-${Date.now()}`,
      organizationId,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      userName,
      userRole,
      action,
      module,
      details
    };
    this.db.auditLogs.unshift(log);
    if (this.db.auditLogs.length > 200) {
      this.db.auditLogs = this.db.auditLogs.slice(0, 200);
    }
    this.save();
    return log;
  }
}

export const dbManager = new DatabaseManager();
