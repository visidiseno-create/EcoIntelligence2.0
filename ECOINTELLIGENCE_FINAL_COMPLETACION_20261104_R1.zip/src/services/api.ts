/**
 * API client for ECOINTELLIGENCE full-stack backend
 */

export interface CurrentUser {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'auditor' | 'operador' | 'lector';
  organizationId: string;
  facilityIds: string[];
}

export interface Organization {
  id: string;
  name: string;
  taxId: string;
  sector: string;
  country: string;
  plan: 'starter' | 'pro' | 'enterprise';
  createdAt: string;
}

export interface Facility {
  id: string;
  organizationId: string;
  name: string;
  code: string;
  address: string;
  coordinates: { lat: number; lng: number };
  activity: string;
  environmentalPermitCode: string;
  status: 'activa' | 'en_mantenimiento' | 'inactiva';
}

class ApiService {
  private activeOrgId: string = 'org-1';
  private currentUserEmail: string = 'admin@ecoinntelligence.com';

  public setContext(orgId: string, userEmail: string) {
    this.activeOrgId = orgId;
    this.currentUserEmail = userEmail;
  }

  public getOrgId(): string {
    return this.activeOrgId;
  }

  public getUserEmail(): string {
    return this.currentUserEmail;
  }

  private headers(): Record<string, string> {
    return {
      'Content-Type': 'application/json',
      'x-organization-id': this.activeOrgId,
      'x-user-email': this.currentUserEmail
    };
  }

  private async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const res = await fetch(endpoint, {
      ...options,
      headers: {
        ...this.headers(),
        ...(options?.headers || {})
      }
    });

    if (!res.ok) {
      let errMsg = `Error ${res.status}: ${res.statusText}`;
      try {
        const data = await res.json();
        if (data.error) errMsg = data.error;
      } catch (_) {}
      throw new Error(errMsg);
    }

    return res.json();
  }

  // Auth
  async login(email: string) {
    const res = await this.request<{
      success: boolean;
      user: CurrentUser;
      organization: Organization;
      availableOrganizations: Organization[];
    }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email })
    });
    this.setContext(res.user.organizationId, res.user.email);
    return res;
  }

  async getMe() {
    return this.request<{
      user: CurrentUser;
      organization: Organization;
      availableOrganizations: Organization[];
    }>('/api/auth/me');
  }

  // Organizations & Facilities
  async getOrganizations() {
    return this.request<Organization[]>('/api/organizations');
  }

  async createOrganization(data: Partial<Organization>) {
    return this.request<Organization>('/api/organizations', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async getFacilities() {
    return this.request<Facility[]>('/api/facilities');
  }

  async createFacility(data: Partial<Facility>) {
    return this.request<Facility>('/api/facilities', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  // Obligations
  async getObligations(params?: { facilityId?: string; status?: string; search?: string }) {
    const query = new URLSearchParams(params as any).toString();
    return this.request<any[]>(`/api/obligations${query ? `?${query}` : ''}`);
  }

  async createObligation(data: any) {
    return this.request<any>('/api/obligations', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async updateObligation(id: string, data: any) {
    return this.request<any>(`/api/obligations/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
  }

  async deleteObligation(id: string) {
    return this.request<any>(`/api/obligations/${id}`, {
      method: 'DELETE'
    });
  }

  // Environmental Records
  async getWaste() {
    return this.request<any[]>('/api/waste');
  }

  async createWaste(data: any) {
    return this.request<any>('/api/waste', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async deleteWaste(id: string) {
    return this.request<any>(`/api/waste/${id}`, { method: 'DELETE' });
  }

  async getWater() {
    return this.request<any[]>('/api/water');
  }

  async createWater(data: any) {
    return this.request<any>('/api/water', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async deleteWater(id: string) {
    return this.request<any>(`/api/water/${id}`, { method: 'DELETE' });
  }

  async getAir() {
    return this.request<any[]>('/api/air');
  }

  async createAir(data: any) {
    return this.request<any>('/api/air', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async deleteAir(id: string) {
    return this.request<any>(`/api/air/${id}`, { method: 'DELETE' });
  }

  async getEnergy() {
    return this.request<any[]>('/api/energy');
  }

  async createEnergy(data: any) {
    return this.request<any>('/api/energy', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async deleteEnergy(id: string) {
    return this.request<any>(`/api/energy/${id}`, { method: 'DELETE' });
  }

  // Inspections & CAPA
  async getInspectionTemplates() {
    return this.request<any[]>('/api/inspections/templates');
  }

  async getInspections() {
    return this.request<any[]>('/api/inspections');
  }

  async createInspection(data: any) {
    return this.request<any>('/api/inspections', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async getCorrectiveActions() {
    return this.request<any[]>('/api/corrective-actions');
  }

  async createCorrectiveAction(data: any) {
    return this.request<any>('/api/corrective-actions', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async updateCorrectiveAction(id: string, data: any) {
    return this.request<any>(`/api/corrective-actions/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
  }

  // Documents
  async getDocuments() {
    return this.request<any[]>('/api/documents');
  }

  async createDocument(data: any) {
    return this.request<any>('/api/documents', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  async deleteDocument(id: string) {
    return this.request<any>(`/api/documents/${id}`, { method: 'DELETE' });
  }

  // Dashboard & Analytics
  async getDashboardAnalytics() {
    return this.request<any>('/api/analytics/dashboard');
  }

  // Assistant
  async askAssistant(query: string) {
    return this.request<any>('/api/assistant/query', {
      method: 'POST',
      body: JSON.stringify({ query })
    });
  }

  // Audit Logs
  async getAuditLogs() {
    return this.request<any[]>('/api/audit-logs');
  }

  // Subscription
  async getSubscription() {
    return this.request<any>('/api/billing/subscription');
  }

  async changeSubscriptionPlan(planId: string) {
    return this.request<any>('/api/billing/change-plan', {
      method: 'POST',
      body: JSON.stringify({ planId })
    });
  }

  // Reset database to initial seed
  async resetSeed() {
    return this.request<any>('/api/system/reset-seed', {
      method: 'POST'
    });
  }
}

export const api = new ApiService();
